How to compile the code:
python version: 3.9
For BFS:
python hw1.py hw1_grid.json --alg bfs --out hw1_bfs.json

For DFS:
python hw1.py hw1_grid.json --alg dfs --out hw1_dfs.json

For Astar:
python hw1.py hw1_grid.json --alg astar --out hw1_astar.json
